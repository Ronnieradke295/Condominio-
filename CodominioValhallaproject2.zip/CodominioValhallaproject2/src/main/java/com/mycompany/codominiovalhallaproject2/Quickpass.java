/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.codominiovalhallaproject2;

public class Quickpass {
    private String filial;
    private String codigo;
    private String placa;

    // Constructor
    public Quickpass(String filial, String codigo, String placa) {
        this.filial = filial;
        this.codigo = codigo;
        this.placa = placa;
    }

    // Métodos getter para obtener los valores de los atributos
    public String getFilial() {
        return filial;
    }

    public String getCodigo() {
        return codigo;  // Este es el método que necesitas para obtener el código
    }

    public String getPlaca() {
        return placa;
    }

    // Métodos setter si los necesitas para modificar los valores
    public void setFilial(String filial) {
        this.filial = filial;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.codominiovalhallaproject2;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SistemaAccesos sistema = new SistemaAccesos();

        // Menú básico de ejemplo
        boolean continuar = true;
        while (continuar) {
            String opcion = JOptionPane.showInputDialog("Seleccione una opción:\n" +
                    "1. Agregar Quickpass\n" +
                    "2. Eliminar Quickpass por Código\n" +
                    "3. Eliminar Quickpass por Placa\n" +
                    "4. Inactivar Quickpass\n" +
                    "5. Verificar Acceso\n" +
                    "6. Mostrar Todos los Quickpasses\n" +
                    "7. Mostrar por Filial\n" +
                    "8. Mostrar por Código\n" +
                    "9. Mostrar Quickpasses Eliminados\n" +
                    "10. Mostrar Quickpasses Eliminados por Filial\n" +
                    "11. Mostrar Quickpass Eliminado por Código\n" +
                    "12. Salir");

            System.out.println("Opción seleccionada: " + opcion); // Imprime la opción seleccionada en consola

            switch (opcion) {
                case "1":
                    sistema.agregarQuickpass();
                    break;
                case "2":
                    sistema.eliminarQuickpassPorCodigo();
                    break;
                case "3":
                    sistema.eliminarQuickpassPorPlaca();
                    break;
                case "4":
                    sistema.inactivarQuickpass();
                    break;
                case "5":
                    sistema.verificarAcceso();
                    break;
                case "6":
                    sistema.mostrarTodos();
                    break;
                case "7":
                    sistema.mostrarPorFilial();
                    break;
                case "8":
                    sistema.mostrarPorCodigo();
                    break;
                case "9":
                    sistema.mostrarEliminados();
                    break;
                case "10":
                    sistema.mostrarEliminadosPorFilial();
                    break;
                case "11":
                    sistema.mostrarEliminadoPorCodigo();
                    break;
                case "12":
                    continuar = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida.");
                    break;
            }
        }
    }
}

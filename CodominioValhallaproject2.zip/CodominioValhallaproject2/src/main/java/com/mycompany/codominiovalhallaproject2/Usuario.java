/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.codominiovalhallaproject2;

import javax.swing.JOptionPane;

public class Usuario {
    private String code = "";

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        // Verificar el formato del código
        String comparar = code.substring(0, 3);
        if (comparar.equals("101") && code.length() == 10) {
            // Si el código es válido, se muestra un mensaje y se guarda el código
            JOptionPane.showMessageDialog(null, "Código válido registrado.");
            this.code = code;
            System.out.println("Código válido registrado: " + code);
        } else {
            // Si el código no es válido, mostrar un mensaje de error
            JOptionPane.showMessageDialog(null, "Código no válido.");
            System.out.println("Código no válido: " + code);
        }
    }
}
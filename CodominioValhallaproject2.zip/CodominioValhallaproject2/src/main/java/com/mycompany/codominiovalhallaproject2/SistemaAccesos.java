/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.codominiovalhallaproject2;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class SistemaAccesos {
    private List<Quickpass> quickpasses;
    private List<Quickpass> quickpassEliminados;

    public SistemaAccesos() {
        this.quickpasses = new ArrayList<>();
        this.quickpassEliminados = new ArrayList<>();
    }

    // Método para agregar un Quickpass
    public void agregarQuickpass() {
        Usuario usuario = new Usuario();
        String codigo = JOptionPane.showInputDialog("Ingrese el código (formato 101XXXXXXX):");
        usuario.setCode(codigo);

        // Solo si el código es válido, se agrega el Quickpass
        if (!usuario.getCode().isEmpty()) {
            String filial = JOptionPane.showInputDialog("Ingrese la filial:");
            String placa = JOptionPane.showInputDialog("Ingrese la placa:");

            Quickpass quickpass = new Quickpass(filial, usuario.getCode(), placa);
            quickpasses.add(quickpass);
            JOptionPane.showMessageDialog(null, "Quickpass agregado exitosamente.");
        }
    }

    // Método para eliminar un Quickpass por código
    public void eliminarQuickpassPorCodigo() {
        String codigo = JOptionPane.showInputDialog("Ingrese el código del Quickpass a eliminar:");
        boolean encontrado = false;

        for (Quickpass quickpass : quickpasses) {
            if (quickpass.getCodigo().equals(codigo)) {
                quickpassEliminados.add(quickpass);
                quickpasses.remove(quickpass);
                JOptionPane.showMessageDialog(null, "Quickpass eliminado exitosamente.");
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "Código no encontrado.");
        }
    }

    // Método para eliminar un Quickpass por placa
    public void eliminarQuickpassPorPlaca() {
        String placa = JOptionPane.showInputDialog("Ingrese la placa del Quickpass a eliminar:");
        boolean encontrado = false;

        for (Quickpass quickpass : quickpasses) {
            if (quickpass.getPlaca().equals(placa)) {
                quickpassEliminados.add(quickpass);
                quickpasses.remove(quickpass);
                JOptionPane.showMessageDialog(null, "Quickpass eliminado exitosamente.");
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "Placa no encontrada.");
        }
    }

    // Método para inactivar un Quickpass
    public void inactivarQuickpass() {
        String codigo = JOptionPane.showInputDialog("Ingrese el código del Quickpass a inactivar:");
        boolean encontrado = false;

        for (Quickpass quickpass : quickpasses) {
            if (quickpass.getCodigo().equals(codigo)) {
                // Aquí puedes agregar lógica para inactivar el Quickpass
                // Por ejemplo, podrías añadir un campo booleano "activo" a la clase Quickpass
                // y cambiar su valor a false.
                // quickpass.setActivo(false);  (este sería un ejemplo)
                JOptionPane.showMessageDialog(null, "Quickpass inactivado exitosamente.");
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "Código no encontrado.");
        }
    }

    // Método para verificar acceso por código
    public void verificarAcceso() {
        String codigo = JOptionPane.showInputDialog("Ingrese el código para verificar acceso:");
        boolean encontrado = false;

        for (Quickpass quickpass : quickpasses) {
            if (quickpass.getCodigo().equals(codigo)) {
                // Aquí puedes agregar la lógica para verificar si el acceso es permitido.
                // Por ejemplo, podrías verificar si el Quickpass está inactivo.
                JOptionPane.showMessageDialog(null, "Acceso permitido.");
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "Código no válido.");
        }
    }

    // Método para mostrar todos los Quickpasses
    public void mostrarTodos() {
        if (quickpasses.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay Quickpasses registrados.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (Quickpass quickpass : quickpasses) {
                sb.append("Filial: ").append(quickpass.getFilial())
                  .append(", Código: ").append(quickpass.getCodigo())
                  .append(", Placa: ").append(quickpass.getPlaca())
                  .append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    // Método para mostrar Quickpasses eliminados
    public void mostrarEliminados() {
        if (quickpassEliminados.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay Quickpasses eliminados.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (Quickpass quickpass : quickpassEliminados) {
                sb.append("Filial: ").append(quickpass.getFilial())
                  .append(", Código: ").append(quickpass.getCodigo())
                  .append(", Placa: ").append(quickpass.getPlaca())
                  .append("\n");
            }
            JOptionPane.showMessageDialog(null, sb.toString());
        }
    }

    // Método para mostrar Quickpasses eliminados por filial
    public void mostrarEliminadosPorFilial() {
        String filial = JOptionPane.showInputDialog("Ingrese la filial para ver Quickpasses eliminados:");
        StringBuilder sb = new StringBuilder();
        boolean encontrado = false;

        for (Quickpass quickpass : quickpassEliminados) {
            if (quickpass.getFilial().equals(filial)) {
                sb.append("Filial: ").append(quickpass.getFilial())
                  .append(", Código: ").append(quickpass.getCodigo())
                  .append(", Placa: ").append(quickpass.getPlaca())
                  .append("\n");
                encontrado = true;
            }
        }

        if (encontrado) {
            JOptionPane.showMessageDialog(null, sb.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No se encontraron Quickpasses eliminados para esa filial.");
        }
    }

    // Método para mostrar Quickpasses eliminados por código
    public void mostrarEliminadoPorCodigo() {
        String codigo = JOptionPane.showInputDialog("Ingrese el código del Quickpass eliminado:");
        StringBuilder sb = new StringBuilder();
        boolean encontrado = false;

        for (Quickpass quickpass : quickpassEliminados) {
            if (quickpass.getCodigo().equals(codigo)) {
                sb.append("Filial: ").append(quickpass.getFilial())
                  .append(", Código: ").append(quickpass.getCodigo())
                  .append(", Placa: ").append(quickpass.getPlaca())
                  .append("\n");
                encontrado = true;
            }
        }

        if (encontrado) {
            JOptionPane.showMessageDialog(null, sb.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No se encontró el Quickpass eliminado con ese código.");
        }
    }

    // Método para mostrar Quickpasses por filial
    public void mostrarPorFilial() {
        String filial = JOptionPane.showInputDialog("Ingrese la filial para ver los Quickpasses:");
        StringBuilder sb = new StringBuilder();
        boolean encontrado = false;

        for (Quickpass quickpass : quickpasses) {
            if (quickpass.getFilial().equals(filial)) {
                sb.append("Filial: ").append(quickpass.getFilial())
                  .append(", Código: ").append(quickpass.getCodigo())
                  .append(", Placa: ").append(quickpass.getPlaca())
                  .append("\n");
                encontrado = true;
            }
        }

        if (encontrado) {
            JOptionPane.showMessageDialog(null, sb.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No se encontraron Quickpasses para esa filial.");
        }
    }

    // Método para mostrar Quickpasses por código
    public void mostrarPorCodigo() {
        String codigo = JOptionPane.showInputDialog("Ingrese el código para ver el Quickpass:");
        StringBuilder sb = new StringBuilder();
        boolean encontrado = false;

        for (Quickpass quickpass : quickpasses) {
            if (quickpass.getCodigo().equals(codigo)) {
                sb.append("Filial: ").append(quickpass.getFilial())
                  .append(", Código: ").append(quickpass.getCodigo())
                  .append(", Placa: ").append(quickpass.getPlaca())
                  .append("\n");
                encontrado = true;
            }
        }

        if (encontrado) {
            JOptionPane.showMessageDialog(null, sb.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No se encontró el Quickpass con ese código.");
        }
    }
}
